% generate_all_figs.m
% Ejecuta todos los generadores y crea las imágenes en ./figures/
p1_generate_figs;
p2_generate_figs;
grupo10_generate_figs;
disp('Figuras generadas en ./figures/. Compila ahora Informe_Problemas_Calidad_Electrica.tex');
