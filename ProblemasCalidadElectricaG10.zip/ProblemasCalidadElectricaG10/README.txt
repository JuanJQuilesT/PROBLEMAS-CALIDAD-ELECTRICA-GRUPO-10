Entrega: Problemas de Calidad Eléctrica (Grupo 10)

Para generar las figuras PNG y compilar el informe:
1) En MATLAB, ejecutar en este orden:
   >> p1_generate_figs
   >> p2_generate_figs
   >> grupo10_generate_figs
   (Se guardan en ./figures/ y ya están referenciadas en el .tex)

2) Compilar LaTeX: Informe_Problemas_Calidad_Electrica.tex

Documento en blanco y negro, portada con logo oficial UAL.
